<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePenyerapanAnggaranTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('penyerapan_anggaran', function (Blueprint $table) {
            $table->id();
            $table->integer('user_id');
            $table->bigInteger('rencana_anggaran');
            $table->integer('tahun_penyerapan_anggaran')->unique();
            $table->bigInteger('realisasi_anggaran');
            $table->bigInteger('sisa_anggaran');
            $table->double('pencapaian');
            $table->string('status_kepala_dinas');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('penyerapan_anggaran');
    }
}
