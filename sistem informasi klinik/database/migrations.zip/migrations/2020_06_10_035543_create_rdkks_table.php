<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateRdkksTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('rdkks', function (Blueprint $table) {
            $table->id();
            $table->integer('id_user');
            $table->integer('pengecer_id');
            $table->integer('pupuk_id');
            $table->integer('jumlah_pupuk');
            $table->date('waktu_penggunaan');
            $table->string('status_dinper');
            $table->string('status_ppl');
            $table->string('status_pengecer');
            $table->integer('user_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('rdkks');
        
    }
}
