<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePengecersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('pengecer', function (Blueprint $table) {
            $table->id();
            $table->string('nama_pengecer');
            $table->string('address');
            $table->string('email')->unique();
            $table->string('avatar')->nullable();
            $table->date('birth_pengecer')->nullable();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('pengecers');
    }
}
